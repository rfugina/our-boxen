# Zlib Puppet Module for Boxen

## Usage

```puppet
include zlib
```

## Required Puppet Modules

* `boxen`
* `homebrew`